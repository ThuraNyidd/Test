import { Inter } from "next/font/google";
import Cookie from "../pages/cookie";
import HomePage from "../pages/Home";
import { useCookies } from 'react-cookie';
const inter = Inter({ subsets: ["latin"] });
import "react-toastify/dist/ReactToastify.css";

export default function Home() {
  const [cookies] = useCookies(["cookieConsent"]);
  return (
    <main className="">
      {/* <Header/> */}
      <HomePage />
      {/* <Curve/> */}
      {!cookies.cookieConsent && <Cookie />}
      {/* <ButtonAnimation /> */}
      {/* <Footer/> */}

      {/* <NavSub/> */}
    </main>
  );
}
