import ErrorComponent from "../components/error-component";

export default function Error() {

  return (
    <>
      <ErrorComponent />
    </>
  )
}