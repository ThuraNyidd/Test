import Cookies from '../components/cookieComponent';

export default function Cookie() {

  return (
    <>
      <Cookies />
    </>
  )
}