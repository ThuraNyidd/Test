import employee1 from './team/ally.png';
import employee2 from './team/dany.png';
import employee3 from './team/alex.png';
import employee5 from './team/clover.png';
import employee6 from './team/Russ.png';
import employee7 from './team/liam.png';
import employee8 from './team/maria.png';
import employee9 from './team/wuki.png';
import employee10 from './team/lily.png';
import employee11 from './team/sonia.png';
import employee12 from './team/honey.png';
import employee13 from './team/chris.png';
import employee14 from './team/leo.png';

export const teamMembers = [

    {
        img: employee1,
        name: 'Htoo Htoo Maw',
        position: 'Product Owner'
    },
    {
        img: employee8,
        name: 'Myint Myat Moe',
        position: 'Senior Business Analyst and QA'
    },
    {
        img: employee11,
        name: 'Su Hnin Aye',
        position: 'Senior Sales & Marketing Executive'
    },
    {
        img: employee14,
        name: 'Hein Zaw Lat',
        position: 'Senior System Engineer '
    },
    {
        img: employee12,
        name: 'Hanni Thein',
        position: 'HR & Admin Executive'
    },
    {
        img: employee2,
        name: 'Htet Su Aung',
        position: 'Senior Full Stack Developer'
    },
    {
        img: employee3,
        name: 'Aung Kyaw Htwe',
        position: ' Full Stack Developer'
    },
    {
        img: employee5,
        name: 'Thet Htar Wai',
        position: 'Frontend  Developer'
    },
    {
        img: employee6,
        name: 'Myo Thant Zaw',
        position: 'UI/UX Designer'
    },
    {
        img: employee9,
        name: 'Kyaw Phyo Linn',
        position: 'Software Support & Tester'
    },
    {
        img: employee7,
        name: 'Kyaw Naing Oo',
        position: 'Junior Graphic Designer'
    },
    {
        img: employee10,
        name: 'Htar Inzali',
        position: 'Junior Software Support & Tester'
    },
    {
        img: employee13,
        name: 'Kyaw Naing Soe',
        position: 'Admin Assistant '
    }
]