import partnerImg1 from '../../components/partners/partnerlogos/partnerlogo1.png'
import partnerImg2 from '../../components/partners/partnerlogos/partnerlogo2.png'
import partnerImg3 from '../../components/partners/partnerlogos/partnerlogo3.png'
import partnerImg4 from '../../components/partners/partnerlogos/partnerlogo4.png'
import partnerImg5 from '../../components/partners/partnerlogos/partnerlogo5.png'
import partnerImg6 from '../../components/partners/partnerlogos/partnerlogo6.png'
import partnerImg7 from '../../components/partners/partnerlogos/partnerlogo7.png'
import partnerImg8 from '../../components/partners/partnerlogos/partnerlogo8.png'
import partnerImg9 from '../../components/partners/partnerlogos/partnerlogo9.png'
import partnerImg10 from '../../components/partners/partnerlogos/partnerlogo10.png'


export const partnerLogos = [
    {
        image: partnerImg1
    },
    {
        image: partnerImg2
    },
    {
        image: partnerImg3
    },
    {
        image: partnerImg4
    },
    {
        image: partnerImg5
    },
    {
        image: partnerImg6
    },
    {
        image: partnerImg7
    },
    {
        image: partnerImg8
    },
    {
        image: partnerImg9
    },
    {
        image: partnerImg10
    },
]