
import news1 from './newsphoto/2c2p 1.jpg';
import news2 from './newsphoto/Pizza Company 1.png';
import news3 from './newsphoto/Air KBZ & MAI 1.png';
import news4 from './newsphoto/POSCO 1.png';
import news5 from './newsphoto/Myanmar Brewery 2.png'
import news6 from './newsphoto/Hi Internet 1.png';
import news7 from './newsphoto/Advance 1.png'
import news8 from './newsphoto/Cycle and Carriage 1.png'
import news9 from './newsphoto/Mask group.png'
import news10 from './newsphoto/Rectangle 27.png'
import news11 from './newsphoto/pic5 1.png'
import news12 from './newsphoto/HRMs.png'
import news13 from './newsphoto/A Bank.jpg'
import news14 from './newsphoto/mingalar.png'
import news15 from './newsphoto/barrier.png'
import news16 from './newsphoto/Skt.png'
import news17 from './newsphoto/embassies.png'
import news18 from './newsphoto/ocean wave.png'
import news19 from './newsphoto/unilink.png'
import news20 from './newsphoto/CBLife.png'

export const newscontent = [
    {
        img: news17,
        content: 'Security Systems For Embassies',
        date: ' 2023 Through out'
    },
    {
        img: news15,
        content: 'Barrier System for 8miles Business Centre',
        date: 'Monday 4th September 2023'
    },
    {
        img: news14,
        content: 'Smilax HR Software Launched For Mingalar Sky',
        date: 'Tuesday 15th August 2023'
    },
    {
        img: news16,
        content: 'Security Systems for SKT Int. School',
        date: 'Friday 7th July 2023'
    },
    {
        img: news13,
        content: 'Customer Support Software Launched For ABank',
        date: 'Wednesday 25th January 2023'
    },
    {
        img: news19,
        content: 'Call Centre Launch for Unilink Myanmar',
        date: 'Wednesday 6th October 2021'
    },
    {
        img: news18,
        content: 'Call Centre Launch for Oceanwave Mandalay ',
        date: 'Thursday 29th July 2021'
    },
    {
        img: news20,
        content: 'Call Centre Launch for CB Life Insurance',
        date: 'Monday 22nd March 2021'
    },
    {
        img: news1,
        content: 'Call Centre Launched For 2C2P',
        date: 'Thursday 1st October 2020'
    },
    {
        img: news6,
        content: 'Call Centre Solution For Hi Internet',
        date: 'Thursday 30th July 2020'
    },

    {
        img: news3,
        content: 'Call Centre Launched For Air KBZ & MAI ',
        date: 'Monday 9th May 2019'
    },
    {
        img: news7,
        content: 'Call Centre Solution Launched For Advans Microfinance',
        date: 'Monday 21st February 2019'
    },
    {
        img: news2,
        content: 'Call Centre Launched for EFG Group(The Pizza Company)',
        date: 'Friday 21st September 2018'
    },
    {
        img: news5,
        content: 'Shipping Import Management System for Myanmar Brewery',
        date: 'Friday 8th September 2017'
    },
    {
        img: news8,
        content: 'Bespoke CAPEX System for Cycle and Carriage, Myanmar',
        date: 'Tuesday 27th June 2017'
    },
    {
        img: news9,
        content: 'Company First Website Launched',
        date: 'Wednesday 9th January 2017'
    },
    {
        img: news10,
        content: 'Start Launching our new products for security solutions',
        date: 'Thursday 1st January 2016'
    },
    {
        img: news11,
        content: 'International Security & Office Solution with Modern Electronics',
        date: 'Friday 9th January 2015'
    },
    {
        img: news4,
        content: 'Server Room Monitoring System Installed  at Posco ',
        date: 'Monday 21st January 2013'
    },
    {
        img: news12,
        content: 'HRMS Solution Launched for Small to Enterprise Levels',
        date: 'Monday 21st January 2013'
    }
]