import image1 from "../../../public/customer_logo/2C2P logo.png"
import image2 from "../../../public/customer_logo/A bank logo.png";
import image3 from "../../../public/customer_logo/ADR logo.png";
import image4 from "../../../public/customer_logo/Arch logo.png";
import image5 from "../../../public/customer_logo/awba logo.png";
import image6 from "../../../public/customer_logo/Aya bank logo.png";
import image7 from "../../../public/customer_logo/AZU logo.png";
import image8 from "../../../public/customer_logo/BSK logo.png";
import image9 from "../../../public/customer_logo/Bergur logo.png";
import image10 from "../../../public/customer_logo/CB logo.png";
import image11 from "../../../public/customer_logo/Che logo.png";
import image12 from "../../../public/customer_logo/Coca Cola logo.png";
import image13 from "../../../public/customer_logo/Coeff logo.png";
import image14 from "../../../public/customer_logo/Cycle logo.png";
import image15 from "../../../public/customer_logo/Easy logo.png";
import image16 from "../../../public/customer_logo/Eda logo.png";
import image17 from "../../../public/customer_logo/EFG logo.png";
import image18 from "../../../public/customer_logo/FIN life logo.png";
import image19 from "../../../public/customer_logo/Food 2u logo.png";
import image20 from "../../../public/customer_logo/GTL logo.png";
import image21 from "../../../public/customer_logo/Internet logo.png";
import image22 from "../../../public/customer_logo/Htwet toe logo.png";
import image23 from "../../../public/customer_logo/ipanema logo.png";
import image24 from "../../../public/customer_logo/Kanaan logo.png";
import image25 from "../../../public/customer_logo/KBZ logo.png";
import image26 from "../../../public/customer_logo/Khit zay logo.png";
import image27 from "../../../public/customer_logo/Meranti logo.png";
import image28 from "../../../public/customer_logo/MGE logo.png";
import image29 from "../../../public/customer_logo/myancare logo.png";
import image30 from "../../../public/customer_logo/Myanmar logo.png";
// import image31 from "../../../public/customer_logo/K_Logo_final_Horizontal.png";
import image32 from "../../../public/customer_logo/posco logo.png";
import image33 from "../../../public/customer_logo/Rent logo.png";
import image34 from "../../../public/customer_logo/SamPar Oo logo.png";
import image35 from "../../../public/customer_logo/skt logo.png";
import image36 from "../../../public/customer_logo/smidb logo.png";
import image37 from "../../../public/customer_logo/STrnnd logo.png";
import image38 from "../../../public/customer_logo/Thai logo.png";
import image39 from "../../../public/customer_logo/Ulink logo.png";
import image40 from "../../../public/customer_logo/Vision logo.png";
import image41 from "../../../public/customer_logo/World Vision logo.png";
import image42 from "../../../public/customer_logo/YinThwy logo.png";
import image43 from "../../../public/customer_logo/Yuqiu logo.png";






// const [image1, image2, image3, image4, image5, image6, image7, image8, image9] = imgs;

export const images = [
    {
        img: image1
    },
    {
        img: image2
    },
    {
        img: image3
    },
    {
        img: image4
    },
    {
        img: image5
    },
    {
        img: image6
    },
    {
        img: image7
    },
    {
        img: image8
    },
    {
        img: image9
    },
    {
        img: image10
    },
    {
        img: image11
    },
    {
        img: image12
    },
    {
        img: image13
    },
    {
        img: image14
    },
    {
        img: image15
    },
    {
        img: image16
    },
    {
        img: image17
    },
    {
        img: image18
    },

    {
        img: image19
    },

    {
        img: image20
    },

    {
        img: image21
    },
    {
        img: image22
    },
    {
        img: image23
    },
    {
        img: image24
    },
    {
        img: image25
    },
    {
        img: image26
    },
    {
        img: image27
    },
    {
        img: image28
    },
    {
        img: image29
    },
    {
        img: image30
    },
    // {
    //     img: image31
    // },
    {
        img: image32
    },
    {
        img: image33
    },
    {
        img: image34
    },

    {
        img: image35
    },
    {
        img: image36
    },
    {
        img: image37
    },

    {
        img: image38
    },
    {
        img: image39
    },

    {
        img: image40
    },
    {
        img: image41
    },
    {
        img: image42
    },
    {
        img: image43
    },



];